# Support CRM business handover

Manual intake · 21 November 2026

Start with the [BRD](brd.pdf) or its [editable edition](brd.md). Read the [product requirements](prd.md) for screen behavior, access rules and failure recovery. Use the [operating guide](business-workflow.md) to walk a case from intake through follow-up, then use the [user stories and acceptance criteria](user-stories.md) for business review. Each story refers to its BRD requirements.

The release-readiness record and transfer runbook cover technical handover and pending rollout decisions. The demo script, portal workspace, register export and notification documents give the receiving team more detail on those workflows. Historical test results belong to their respective releases.
